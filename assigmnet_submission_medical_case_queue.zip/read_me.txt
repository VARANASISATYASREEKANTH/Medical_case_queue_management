[1] The 'script_main2.py' is the script to Build an AI Agent for Medical Case Queue Management. 
[2] The queue management task is taken care by Principal Policy Optimization(PPO), by taking feed from file "patient_data.csv".
[3] The case queue management of patients with doctors can be tapped from output of `test_agent(env, model)' at line number 138 of script 2.
[4] The evaluation metrics are save to the CSV file "metrics_evaluation_results.csv"(due to computational resource limitation, the output was not generated). In the metrics definition of section 5, 'E' indicates the expectation.
